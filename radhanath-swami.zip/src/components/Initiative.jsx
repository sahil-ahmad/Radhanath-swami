import React from 'react'
import { Link } from 'react-router-dom'

const Initiative = () => {
    return (
        <>
            <div className='initiative'>
                <div className='init-container'>
                    <div className='init-list'>
                        <Link to='/vani'>VANI SCHOOL</Link>
                        <Link to='/recovery'>THE RECOVERY ANNEX</Link>
                        <Link>GOVERDHAN</Link>
                        <Link>HOSPITAL</Link>
                        <Link>MIDDAY MEAL</Link>
                        <Link to='/bhakti'>BHAKTI YOGA</Link>
                    </div>
                    <div className='init-content'></div>
                </div>


            </div>
        </>
    )
}

export default Initiative
