import React from 'react'

const Exprience = () => {
    return (
        <>
            <div className='exprience'>
                <div className='e-container'>
                    <div className='e-content'>
                        <h2>EXPERIENCE</h2>
                        <h1>His Holiness speaks at events <br />all around the world</h1>
                        <p>Discover upcoming and past events</p>
                        <button>FIND HERE</button>
                    </div>
                </div>


            </div>
        </>
    )
}

export default Exprience
