
import vanioffer1 from "../components/assets/vanioffer1.jpg"
import vanioffer2 from './assets/vanioffer2.jpg'
import vanioffer3 from './assets/vanioffer3.jpg'
import vanioffer5 from './assets/vanioffer5.jpg'
import vanioffer6 from './assets/vanioffer6.jpg'
import rcimg1 from './assets/r-c-img1.webp'
import rcimg2 from './assets/r-c-img2.webp'
import rcimg3 from './assets/r-c-img3.webp'
export const Data = [
    {
        id: 1,
        tital: 'COURSES',
        description: 'Spirituality',

        img: vanioffer1
    }
    // {
    //     id:1,
    //     tital:'COURSES',
    //     description:'z'

    // }
    ,
    {
        id: 2,
        tital: 'WORK BOOKLETS',
        description: 'Offering guidance & reflections',

        img: vanioffer2,
    },
    {
        id: 3,
        tital: 'MOBILE APP',
        description: 'Available on iOS and Android',

        img: vanioffer3
    },
    {
        id: 4,
        tital: 'COMMUNITY',
        description: 'Join like-minded souls',

        img: vanioffer5
    },
    {
        id: 5,
        tital: 'LIVE SESSIONS',
        description: 'Interact with course teachers live',

        img: vanioffer6
    },
    {
        id: 6,
        rctital: '6 WEEK PROGRAM',
        rcdescription: 'All-inclusive 12-Step & bhakti-oriented fellowship',
        rcimg: rcimg1
    },
    {
        id: 7,
        rctital: 'COMMUNITY',
        rcdescription: 'Connecting with like-minded people',
        rcimg: rcimg2
    },
    {
        id: 8,
        rctital: 'BHAKTI TRADITION',
        rcdescription: 'Spiritual guidance with compassion',
        rcimg: rcimg3
    },






]