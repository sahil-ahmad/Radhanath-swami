import React from 'react'
import { Link } from 'react-router-dom'

const Resources = () => {
  return (
    <>
      <div className='resource'>
                <div className='resource-container'>
                    <div className='resource-list'>
                        <Link to='/media'>MEDIA</Link>
                        <Link to='/books'>BOOKS</Link>
                        <Link to='/teaching'>TEACHINGS</Link>
                    </div>
                </div>
            </div>
    </>
  )
}

export default Resources
