import React from 'react';
import logo from './assets/RNS-Logo.webp';
import { Link, NavLink, useNavigate } from 'react-router-dom';

const Navbar = () => {
    // const navigate = useNavigate();

    // const handleAboutClick = () => {
    //     navigate('/about');
    // };

    return (
        <>
            <div className='navbar'>
                <div className='logo'>
                    <Link to='/'><img src={logo} alt="Logo" /></Link>
                </div>
                <div className='nav'>
                    <Link to={'/about'}>

                        <a className='about-section'>
                            ABOUT
                        </a>
                  
                    </Link>
                    <NavLink to='/initiative'>INITIATIVES</NavLink>
                    <NavLink to='/resources'>RESOURCES</NavLink>
                    <NavLink to='/get-involved'>GET INVOLVED</NavLink>
                    <NavLink to='/newsletter'>NEWSLETTER</NavLink>
                    <NavLink to='/contact'>CONTACT</NavLink>
                </div>
                {/* <div className='icon'>
                    <i className="fa-solid fa-bars"></i>
                    <p>MENU</p>
                </div> */}
            </div>
        </>
    );
};

export default Navbar;
