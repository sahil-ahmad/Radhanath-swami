import React from 'react'

const Thought = () => {
    return (
        <>
            <div className='thought'>
                <div className='thought-container'>
                    <div className='th-content'>
                        <h2>Things can give pleasure to the mind and<br /> senses, but only love can give pleasure to the<br /> heart. And ultimately, that is what we are<br /> looking for.</h2>
                        <h3>RADHANATH SWAMI</h3>
                    </div>

                </div>
            </div>
        </>
    )
}

export default Thought
